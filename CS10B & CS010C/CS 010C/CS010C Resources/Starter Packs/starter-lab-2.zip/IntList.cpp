#include "IntList.h"

#include <iostream>
#include <exception>

// This is OK, but you can (and should) do 'using std::ostream;' instead
using namespace std;

// TURD: This is just for the throws during the
// development phase... it is a turd once
// you remove all the HERE's
// Please remove before submitting
#define STRINGIZE(x) #x
#define STR(x) STRINGIZE(x)
#define HERE ("Broken at\n" __FILE__ ":" STR(__LINE__) ": broken")

#include <iostream>
ostream & operator<<(ostream &out, const IntList &rhs) {
  throw runtime_error(HERE);
  return out;
}

IntList::~IntList() {
  // TURD: You can't actually throw an exception in a destructor "as-is"
  // TURD: throw runtime_error(HERE);
}

void IntList::push_front(int value) {
  throw runtime_error(HERE);
}

void IntList::pop_front() {
  throw runtime_error(HERE);
}

void IntList::push_back(int value) {
  throw runtime_error(HERE);
}

void IntList::pop_back() {
  throw runtime_error(HERE);
}

bool IntList::empty() const {
  throw runtime_error(HERE);
}

void IntList::printReverse() const {
  throw runtime_error(HERE);
}

