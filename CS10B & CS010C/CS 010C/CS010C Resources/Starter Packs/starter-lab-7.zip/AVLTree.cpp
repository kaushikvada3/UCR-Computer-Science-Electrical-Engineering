#include "AVLTree.h"

#include <iostream>
using namespace std;

AVLTree::AVLTree()
  : root(nullptr)
{
}

// This is a helper function that traverses the tree to compute the height
static int computed_height(const Node* subtree) {
  if (subtree == nullptr) return 0;
  return max(computed_height(subtree->left),computed_height(subtree->right))+1;
}


// We visualize a tree as text (there are some notes about doing this with VizGraph
// but it has never been worth the effort to get that part working)
void AVLTree::visualizeTree(const Node* subtree,int indent) const {
  // Indenting some spaces
  for(int i=0;i<indent;++i) {
    cout << ' ';
  }

  if (subtree == nullptr) {
    cout << "-empty-" << endl;
  } else {
    cout << subtree->data << ' ' << '(' << (computed_height(subtree->left)-computed_height(subtree->right)) << ')' << endl;
    visualizeTree(subtree->left,indent+4);
    visualizeTree(subtree->right,indent+4);
  }
}
