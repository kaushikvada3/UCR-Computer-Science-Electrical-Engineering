// TURD: In .cpp files that are not implementation files, we put
// TURD: the system file includes first
#include <iostream>
#include <limits>

// TURD: Then user files
#include "Playlist.h"

// TURD: It's ok to use 'using namespace std;' here, but this is better
using std::cin;
using std::cout;
using std::endl;
using std::getline;
using std::numeric_limits;
using std::string;
using std::streamsize;

void PrintMenu(const string& title) {
  cout << title << endl;
}

int main() {
  string title;
  string command;

  // Prompt for and read the title for the playlist (may contain spaces)
  cout << "Enter playlist's title:" << endl;
  cout << endl;
  getline(cin, title);
  // TURD: I need to do something here, don't I

  // Build a playlist object with this title
  Playlist playlist(title);

  // Read the next "token".  Will stop on EOF or a q
  playlist.menu();
  while (cin >> command and command != "q") {
    // ignore characters until we get to a newline or end-of-file
    cin.ignore(numeric_limits<streamsize>::max(),'\n');

    if (command == "a") {
      // Enter song's unique ID:
      // Enter song's name:
      // Enter artist's name:
      // Enter song's length (in seconds):
      playlist.add(uniqueID, songName, artistName, songLength);
    }

    else if (command == "d") {
    }

    else if (command == "c") {
    }

    else if (command == "s") {
    }

    else if (command == "t") {
    }

    else if (command == "o") {
    }

    // Repeat the menu and wait for another command
    playlist.menu();
  }

  // TURD: Always remember to add the return here.  0 means it finished properly
  return 0;
}
