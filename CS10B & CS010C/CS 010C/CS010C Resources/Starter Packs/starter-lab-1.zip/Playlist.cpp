// TURD: For .cpp files that match a header, we include the header file first
#include "Playlist.h"

// TURD: Then system headers (alphabetical)
#include <iostream>
#include <string>

PlaylistNode::PlaylistNode()
  : uniqueID("none") {
}

