// TURD: This form is better than the #ifndef guard
#pragma unique

// TURD: "include what you use".. we just need std::string here
#include <string>

// TURD: DO NOT PUT "using namespace std;" in an include file!
// TURD: You can either do "using std::string;" or just put std::string
// TURD: everywhere in the HEADER where you want a string

class PlaylistNode {
 private:
  std::string uniqueID;
  // TURD: More fields have to be defined
 public:
  PlaylistNode();
  // TURD: Define a constructor for a playlist with a title
  // TURD: You'll also need a destructor (pay mind to the rule of three!)
  // TURD: More methods have to be defined
};

class Playlist {
 private:
  PlaylistNode* head = nullptr;
  PlaylistNode* tail = nullptr;
 public:
  // TURD: Define a constructor for a playlist with a title
  // TURD: More methods have to be defined
};

