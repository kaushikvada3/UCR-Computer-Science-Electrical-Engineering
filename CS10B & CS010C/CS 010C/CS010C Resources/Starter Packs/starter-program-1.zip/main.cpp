#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

struct Node {
    string payload;
    Node* next;
  // TURD: Note that there is no constructor here. We will
  // TURD: directly manipulate payload and next, but be
  // TURD: careful.  Whilst payload will be an empty string
  // TURD: the value inside next is undefined.
};


// TURD: This acts like a call to 'new' with a constructor.  So be
// TURD: sure to call the allocator AND set up the payload/next data
// TURD: And the original passed in the string by value.  const& is
// TURD: better here for passing in the payload
Node* newNode(const string& payload) {
  // TURD: complete this
  return nullptr;
}

// TURD: The original passed in the vector by value.  Not the best
// TURD: choice!
Node* loadGame(int n, const vector<string>& names) {
    Node* head = nullptr;
    Node* prev = nullptr;
    string name;

    for (int i = 0; i < n; ++i) {
        name = names.at(i);
	// Special edge case when the list is initially empty
        if (head == nullptr) {
            head = newNode(name);
	    prev = head;
        } else {
            prev->next = newNode(name);
	    prev = prev->next;
        }
    }

    if (prev != nullptr) {
      prev->next = head;
    }
    return head;
}

// TURD: The orginal zybook code passed this as a Node*
// TURD: instead of const Node*.  Why is const Node*
// TURD: better?
// prints list from a starting node
void print(const Node* start) {
  const Node* curr = start;
  // TURD: Ask yourself, why we check for nullptr here and provide
  // TURD: a good comment on why we have to check it since we're
  // TURD: really using the `currr == start` check below to break
  // TURD: out of the loop
  while (curr != nullptr) {
    cout << curr->payload << endl;
    curr = curr->next;
    if (curr == start) {
      break; // exit circular list
    }
  }
}

// josephus w circular list, k = num skips
Node* runGame(Node* start, int k) {
  if (start == nullptr) return nullptr;

  Node* curr = start;
  Node* prev = curr;
  while (curr->next != curr) { // exit condition, last person standing


    for (int i = 0; i < k; ++i) { // find kth node
      prev = curr;
      curr = curr->next;
    }

    // TURD -- This is the code you are supposed to write
    /** fill in this code **/ // delete kth node
    
    Node* next = curr->next;
    prev->next = next;
    delete curr;
    curr = next;
  }

  return curr; // last person standing
}

/* Driver program to test above functions */
int main() {
  int n=1, k=1, max; // n = num names; k = num skips (minus 1)
  string name;
  vector<string> names;

  // get inputs
  cin >> n >> k;
  // TURD: We just need to check before we USE n or k.  The original code
  // TURD: in zybooks didn't bother to check -- naughty, naughty!
  if (!cin) throw runtime_error("error reading n and k from input");
    
  while (cin >> name && name != ".") { names.push_back(name); } // EOF or . ends input

  // initialize and run game
  Node* startPerson = loadGame(n, names);
  Node* lastPerson = runGame(startPerson, k);

  if (lastPerson != nullptr) {
    cout << lastPerson->payload << " wins!" << endl;
  } else {
    cout << "error: null game" << endl;
  }

  return 0;
}

