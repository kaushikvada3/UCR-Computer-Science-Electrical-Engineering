#include <iostream>
#include "Heap.h"

using namespace std;

Heap::Heap()
  : numItems(0)
{
}

//Heap::~Heap() { ... }
//Other rule of three stuff too!


void Heap::enqueue(PrintJob* job) {
}

void Heap::dequeue() {
}

PrintJob* Heap::highest() {
  return nullptr;
}

void Heap::print() const {
}
