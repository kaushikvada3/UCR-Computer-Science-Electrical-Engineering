#include "BSTree.h"

#include <iostream>

using namespace std;

void BSTree::insert(const string& key) {
  throw runtime_error("not done insert");
}

bool BSTree::search(const string& key) const {
  throw runtime_error("not done search");
}

string BSTree::largest() const {
  throw runtime_error("not done largest");
}

string BSTree::smallest() const {
  throw runtime_error("not done smallest");
}

int BSTree::height(const string& key) const {
  throw runtime_error("not done height");
}

void BSTree::remove(const string& key) {
  throw runtime_error("not done remove");
}

void BSTree::preOrder() const {
  throw runtime_error("not done preOrder");
}
void BSTree::postOrder() const {
  throw runtime_error("not done postOrder");
}
void BSTree::inOrder() const {
  throw runtime_error("not done inOrder");
}

void BSTree::remove(Node* parent, Node* tree, const string& key) {
  // Hint: A good approach is to find the parent and the curr node that holds that key


  // Edge case: The key is not found (do nothing)

  // Edge case.  The key count is greater than 1.  Just decrement the count


  // Edge case: leaf (no children).  Just remove from parent
  //  ==> case 1: parent is nullptr (we are removing the last node from root)
  //  ==> case 2: curr is the left child, remove it from parent
  //  ==> case 3: curr is the right child, remove it from parent

    // Typical case.  Find the target
    // It is either the largest key in the left tree (if one exists)
    // or the smallest key in the right tree (since not a leaf one will exist)
    // Copy the target information into the node we found, set the target count to
    // one, and recursively remove it from left or right subtree (current node is the parent)

  throw runtime_error("not done remove");
}

int BSTree::height_of(Node* tree) const {
  // The height (length of longest path to the bottom) of an empty tree is -1
  // Otherwise, you pick the larger of the left height and the right height
  // and add one to that
  throw runtime_error("not done height_of");
}

void BSTree::preOrder(Node* tree) const {
  // print key, do left, do right
  throw runtime_error("not done preOrder");
}

void BSTree::postOrder(Node* tree) const {
  // do left, do right, print key
  throw runtime_error("not done postOrder");
}

void BSTree::inOrder(Node* tree) const {
  // do left, print key, do right
  throw runtime_error("not done inOrder");
}

void BSTree::debug(Node* tree, int indent) const {
  // This is a pre-order traversal that shows the full state of the tree
  if (tree == nullptr) return;
  for(int i=0;i<4*indent;++i) cout << ' ';
  cout << tree << ' ' << *tree << endl;
  debug(tree->left,indent+1);
  for(int i=0;i<4*indent;++i) cout << ' ';
  cout << "-" << endl;
  debug(tree->right,indent+1);
}
